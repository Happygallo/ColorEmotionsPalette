//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.


import Foundation
import SwiftUI
import PlaygroundSupport

var joy, trust, fear, surprise, sadness, disgust, anger, anticipation: UIColor

var img: UIImage

//#-end-hidden-code

/*:
 
 # From colors to images
 
 I hope you have learned something new today. Run the playground and experiment with the feeling colors and images.
 
 Thank you.

 */

// Color selection
joy = /*#-editable-code Text to be shown*/#colorLiteral(red: 0.9607843137254902, green: 0.7058823529411765, blue: 0.2, alpha: 1.0)/*#-end-editable-code*/
trust = /*#-editable-code Text to be shown*/#colorLiteral(red: 0.4666666666666667, green: 0.7647058823529411, blue: 0.26666666666666666, alpha: 1.0)/*#-end-editable-code*/
fear = /*#-editable-code Text to be shown*/#colorLiteral(red: 0.27450980392156865, green: 0.48627450980392156, blue: 0.1411764705882353, alpha: 1.0)/*#-end-editable-code*/
surprise = /*#-editable-code Text to be shown*/#colorLiteral(red: 0.12941176470588237, green: 0.21568627450980393, blue: 0.06666666666666667, alpha: 1.0)/*#-end-editable-code*/
sadness = /*#-editable-code Text to be shown*/#colorLiteral(red: 0.17647058823529413, green: 0.4980392156862745, blue: 0.7568627450980392, alpha: 1.0)/*#-end-editable-code*/
disgust = /*#-editable-code Text to be shown*/#colorLiteral(red: 0.12156862745098039, green: 0.011764705882352941, blue: 0.4235294117647059, alpha: 1.0)/*#-end-editable-code*/
anger = /*#-editable-code Text to be shown*/#colorLiteral(red: 0.7450980392156863, green: 0.1568627450980392, blue: 0.07450980392156863, alpha: 1.0)/*#-end-editable-code*/
anticipation = /*#-editable-code Text to be shown*/#colorLiteral(red: 0.9372549019607843, green: 0.34901960784313724, blue: 0.19215686274509805, alpha: 1.0)/*#-end-editable-code*/

// Image selection
img = /*#-editable-code Text to be shown*/#imageLiteral(resourceName: "img")/*#-end-editable-code*/


//#-hidden-code

struct ContentView: View {
    
    
    
    @State var myFeelings = Feelings(feelings:[
        Feeling(feeling: "Joy", emoji: "😂", color:  joy),
        Feeling(feeling: "Trust", emoji: "😌", color: trust),
        Feeling(feeling: "Fear", emoji: "😰", color: fear),
        Feeling(feeling: "Surprise", emoji: "😮", color: surprise),
        Feeling(feeling: "Sadness", emoji: "😢", color: sadness),
        Feeling(feeling: "Disgust", emoji: "🤮", color: disgust),
        Feeling(feeling: "Anger", emoji: "😡", color: anger),
        Feeling(feeling: "Anticipation", emoji: "😏", color: anticipation)
    ])
    
    @State private var selectedFeeling: String?
    @State private var selectedColor: UIColor?
    
    var body: some View {
        ZStack {
            VStack {
                
                HStack {
                    VStack(alignment: .leading) {
                        
                        Text("R: \(RGBColor.getRed(color: selectedColor ?? UIColor.black))")
                        .font(.system(size: 20, weight: .semibold))
                        
                        Text("G: \(RGBColor.getGreen(color: selectedColor ?? UIColor.black))")
                        .font(.system(size: 20, weight: .semibold))
                        
                        Text("B: \(RGBColor.getBlue(color: selectedColor ?? UIColor.black))")
                        .font(.system(size: 20, weight: .semibold))
                    }
                    Spacer()
                    
                }
                
                ZStack {
                    Image(uiImage: img)
                    .resizable()
                    .scaledToFit()
                    .overlay(Color(selectedColor ?? UIColor.black).opacity(0.1))
                }
                
                ZStack {
                    
                    Rectangle()
                        .frame(height: 100)
                        .foregroundColor(Color(#colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)))
                    
                    HStack(spacing:0) {
                        
                        ForEach(myFeelings.feelings.indices) { index in
                            HStack {
                                if self.myFeelings.feelings[index].selected {
                                    ZStack {
                                        
                                        Button(action: {
                                            if self.selectedFeeling == self.myFeelings.feelings[index].feeling {
                                                self.selectedFeeling = ""
                                                self.selectedColor = nil
                                            } else {
                                                self.selectedFeeling = self.myFeelings.feelings[index].feeling
                                                self.selectedColor = self.myFeelings.feelings[index].color
                                            }
                                            
                                            
                                        }) {
                                            Rectangle()
                                                .frame(height: 100)
                                                
                                                .foregroundColor(Color(self.myFeelings.feelings[index].color))
                                                .scaledToFill()
                                                
                                                
                                                .border(Color.white, width: self.selectedFeeling == self.myFeelings.feelings[index].feeling ? 5 : 0)
                                            
                                        }
                                        
                                    }
                                    
                                }
                            }
                            
                        }
                        
                    }
                    
                }
                .padding(.top, 50)
                .shadow(color: Color.black.opacity(0.15), radius: 5, x: 0, y: 0)
                
                HStack {
                    ForEach(myFeelings.feelings.indices) { index in
                        ZStack {
                            Button(action: {
                                self.myFeelings.feelings[index].selected.toggle()
                                if self.selectedFeeling == self.myFeelings.feelings[index].feeling {
                                    self.selectedFeeling = ""
                                }
                            }) {
                                Text(self.myFeelings.feelings[index].emoji)
                                    .font(.system(size: 40))
                                    .opacity(self.myFeelings.feelings[index].selected ? 0.3 : 1)
                            }
                        }
                    }
                }
                
            }
            .padding(.horizontal, 100)
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
//#-end-hidden-code
