//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.

var joy, trust, fear, surprise, sadness, disgust, anger, anticipation: String

//#-end-hidden-code

/*:
 
 # From emotions to emoji
 Every day we use emoji to communicate emotion through social media, I want you to run the playground and select the emotions you identified of the past days with the emoji present.
 
 You should see that different color appears depending in the emoji you selected. I will show you where those colors come from on the next page but for now let's focus on the emoji. Each emoji represents one emotion, but maybe it happens that the emoji you see isn’t the best representation of the emotion for you, try to those who best suit you.
 
 */

// Emoji selection
joy = /*#-editable-code Text to be shown*/"😂"/*#-end-editable-code*/
trust = /*#-editable-code Text to be shown*/"😌"/*#-end-editable-code*/
fear = /*#-editable-code Text to be shown*/"😰"/*#-end-editable-code*/
surprise = /*#-editable-code Text to be shown*/"😮"/*#-end-editable-code*/
sadness = /*#-editable-code Text to be shown*/"😢"/*#-end-editable-code*/
disgust = /*#-editable-code Text to be shown*/"🤮"/*#-end-editable-code*/
anger = /*#-editable-code Text to be shown*/"😡"/*#-end-editable-code*/
anticipation = /*#-editable-code Text to be shown*/"😏"/*#-end-editable-code*/

/*:
 
 [Next Page: From emoji to colors](@next)
 
 */

//#-hidden-code

import Foundation
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    
    @State var myFeelings = Feelings(feelings:[
        Feeling(feeling: "Joy", emoji: joy, color:  UIColor(#colorLiteral(red: 0.9607843137254902, green: 0.7058823529411765, blue: 0.2, alpha: 1.0))),
        Feeling(feeling: "Trust", emoji: trust, color: UIColor(#colorLiteral(red: 0.4666666666666667, green: 0.7647058823529411, blue: 0.26666666666666666, alpha: 1.0))),
        Feeling(feeling: "Fear", emoji: fear, color: UIColor(#colorLiteral(red: 0.27450980392156865, green: 0.48627450980392156, blue: 0.1411764705882353, alpha: 1.0))),
        Feeling(feeling: "Surprise", emoji: surprise, color: UIColor(#colorLiteral(red: 0.12941176470588237, green: 0.21568627450980393, blue: 0.06666666666666667, alpha: 1.0))),
        Feeling(feeling: "Sadness", emoji: sadness, color: UIColor(#colorLiteral(red: 0.17647058823529413, green: 0.4980392156862745, blue: 0.7568627450980392, alpha: 1.0))),
        Feeling(feeling: "Disgust", emoji: disgust, color: UIColor(#colorLiteral(red: 0.12156862745098039, green: 0.011764705882352941, blue: 0.4235294117647059, alpha: 1.0))),
        Feeling(feeling: "Anger", emoji: anger, color: UIColor(#colorLiteral(red: 0.7450980392156863, green: 0.1568627450980392, blue: 0.07450980392156863, alpha: 1.0))),
        Feeling(feeling: "Anticipation", emoji: anticipation, color: UIColor(#colorLiteral(red: 0.9372549019607843, green: 0.34901960784313724, blue: 0.19215686274509805, alpha: 1.0)))
    ])
    
    @State private var selectedFeeling: String?
    
    var body: some View {
        ZStack {
            VStack {
                
                ZStack {
                    
                    Rectangle()
                        .frame(height: 100)
                        .foregroundColor(Color(#colorLiteral(red: 0.8039215803, green: 0.8039215803, blue: 0.8039215803, alpha: 1)))
                    
                    Text("Select different emojis to create your color feelings palette")
                    .foregroundColor(Color(#colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)))
                    
                    HStack(spacing:0) {
                        
                        ForEach(myFeelings.feelings.indices) { index in
                            HStack {
                                if self.myFeelings.feelings[index].selected {
                                    ZStack {
                                        
                                        Rectangle()
                                            .frame(height: 100)
                                            
                                            .foregroundColor(Color(self.myFeelings.feelings[index].color))
                                            .scaledToFill()
                                            .border(Color.white, width: self.selectedFeeling == self.myFeelings.feelings[index].feeling ? 5 : 0)
                                    }
                                    
                                }
                            }
                            
                        }
                        
                    }
                    
                }
                .shadow(color: Color.black.opacity(0.15), radius: 5, x: 0, y: 0)
                
                HStack {
                    ForEach(myFeelings.feelings.indices) { index in
                        ZStack {
                            Button(action: {
                                self.myFeelings.feelings[index].selected.toggle()
                                if self.selectedFeeling == self.myFeelings.feelings[index].feeling {
                                    self.selectedFeeling = ""
                                }
                            }) {
                                Text(self.myFeelings.feelings[index].emoji)
                                    .font(.system(size: 40))
                                    .opacity(self.myFeelings.feelings[index].selected ? 0.3 : 1)
                            }
                        }
                    }
                }
                
            }
            .padding(.horizontal, 100)
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
//#-end-hidden-code
