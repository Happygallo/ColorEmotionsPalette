//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.

//#-end-hidden-code

/*:
 
 # Colors and Emotions
 Hi, my name is Javier and I'm a visual artist student.
  
 Today I want to teach you about color psycology in this swift playground I made using SwiftUI.
 
 
 ### Why does movies, logos and advertisings use the colors they use?
 
 Colors are capable of changing our emotions or feelings, for example food is almost always orange, that is why many restaurants use red or yellow in their logos to make you hungry. But if you are looking for some healthy food, maybe a restaurant with a green logo could seem better. The same thing happens in movies, when they are sad, they usually use colors like blue. But if it is about a romantic comedy, they usually use colors like yellow.
 
 Now, before you start, I invite you to think for a few seconds on the last emotions or feelings you have had in the last days. If your feel ready you can continue.

 
 [Next Page: From feelings to emoji](@next)
 
 */
