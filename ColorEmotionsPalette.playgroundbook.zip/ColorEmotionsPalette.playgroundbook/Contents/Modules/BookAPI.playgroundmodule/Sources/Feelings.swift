//
//  File.swift
//  Playground Test
//
//  Created by Javier Gallo Roca on 16/05/20.
//  Copyright © 2020 Javier Gallo Roca. All rights reserved.
//

import Foundation
import SwiftUI
import Combine

public var joy: String = "😀"

public struct Feelings {
    public var feelings: [Feeling]
    
    public init(feelings: [Feeling]) {
        self.feelings = feelings
    }
    
}
