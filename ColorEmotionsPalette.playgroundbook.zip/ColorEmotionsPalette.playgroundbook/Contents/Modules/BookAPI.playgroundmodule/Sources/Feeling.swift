//
//  Feeling.swift
//  Playground Test
//
//  Created by Javier Gallo Roca on 13/05/20.
//  Copyright © 2020 Javier Gallo Roca. All rights reserved.
//

import Foundation
import SwiftUI

public struct Feeling {
    
    public var feeling: String
    public var emoji: String
    public var color: UIColor
    public var selected = false
    
    public init(feeling: String, emoji: String, color:  UIColor) {
        self.feeling = feeling
        self.emoji = emoji
        self.color = color
    }
    
}
