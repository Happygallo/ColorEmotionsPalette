//
//  rgbColor.swift
//  Playground Test
//
//  Created by Javier Gallo Roca on 17/05/20.
//  Copyright © 2020 Javier Gallo Roca. All rights reserved.
//

import Foundation
import SwiftUI

public class RGBColor {
    
    init() {
    }
    
    public static func getRed(color: UIColor) -> Int {
        let ciColor = CIColor(color: color)
        let red = (Double(ciColor.red.description)! * 255)
        return Int(red)
    }
    
    public static func getGreen(color: UIColor) -> Int {
        let ciColor = CIColor(color: color)
        let green = (Double(ciColor.green.description)! * 255)
        return Int(green)
    }
    
    public static func getBlue(color: UIColor) -> Int {
        let ciColor = CIColor(color: color)
        let blue = (Double(ciColor.blue.description)! * 255)
        return Int(blue)
    }
}
